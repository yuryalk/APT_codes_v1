clear;figure(2);clf;colormap jet
% physics
% independent
Lx          = 1;
v0          = 1;
eta         = 1e6;
G0          = 1;
k_etaf      = 1.0;
% scales
p0          = eta*v0/Lx;
% dependent
Ly          = 1*Lx; Lz = Lx;
% numerics
nx          = 61;
ny          = 1*nx; nz = nx;
CFL         = 0.8*1/sqrt(3);
K_G_opt     = 1;
R_e_opt     = 2*pi;
niter       = 50*max(nx,ny);
abstol      = 1*1e-3;
reltol      = 1*1e-5;
% preprocessing
dx          = Lx/(nx-1);
dy          = Ly/(ny-1);
dz          = Ly/(ny-1);
[x,y,z]     = ndgrid(-Lx/2:dx:Lx/2,-Ly/2:dy:Ly/2,-Lz/2:dz:Lz/2);
[xVx,yVx,zVx] = ndgrid(-Lx/2-dx/2:dx:Lx/2+dx/2,-Ly/2:dy:Ly/2,-Lz/2:dz:Lz/2);
[xVy,yVy,zVy] = ndgrid(-Lx/2:dx:Lx/2,-Ly/2-dy/2:dy:Ly/2+dy/2,-Lz/2:dz:Lz/2);
[xVz,yVz,zVz] = ndgrid(-Lx/2:dx:Lx/2,-Ly/2:dy:Ly/2,-Lz/2-dz/2:dz:Lz/2+dz/2);
% parameter grid
R_e       = R_e_opt*linspace(0.5,7,11);
iters     = 0*R_e;
Vpdt      = CFL*min(dx,dy);
for irun = 1:numel(R_e)
    irun
    eta_ve   = 1./(1./eta*1  + 1./( G0 +4/3*G0 ));
    dt_rho  = Vpdt./(R_e(irun)./eta_ve);
    Gdt     = Vpdt^2./dt_rho/(K_G_opt+4/3);
    Kdt       = K_G_opt*Gdt;
    rho_dt    = 1./dt_rho;
    Gr      = Gdt./G0;
    Kr      = Kdt./G0;
    % init
    Vx   =  1*v0*sin(pi/1*xVx / Lx      ) .*cos(pi*yVx /(Ly-  dy));%.*cos(pi*zVx /(Lz-  dz))   .*cos(pi*yVx /(Ly-  dy))
    Vy   = -0*1*v0*cos(pi*xVy /(Lx-  dx)).*sin(pi*yVy / Ly      );
    Vz   = +0*1*v0*cos(pi*xVz /(Lx-  dx)).*sin(pi*zVz / Ly      );
    Qx   =  1*v0*sin(pi*xVx / Lx      ).*cos(pi*yVx /(Ly-  dy)).*cos(pi*zVx /(Lz-  dz));
    Qy   = -0*1*v0*cos(pi*xVy /(Lx-  dx)).*sin(pi*yVy / Ly      );
    Qz   = +0*1*v0*cos(pi*xVz /(Lx-  dx)).*sin(pi*zVz / Ly      );
    %Vz = zeros(nx,ny,nz+1);
    
    Txx    = zeros(nx,ny,nz) ;
    Tyy    = zeros(nx,ny,nz) ;
    Tzz    = zeros(nx,ny,nz);
    Txy    = zeros(nx+1,ny+1,nz) ;
    Txz    = zeros(nx+1,ny,nz+1) ;
    Tyz    = zeros(nx,ny+1,nz+1) ;
     P    =  0*p0*cos(pi*x  /(Lx-  dx)).*cos(pi*y  /(Ly-  dy));
     Pf    =  0*1*p0*cos(pi*x  /(Lx-  dx)).*cos(pi*y  /(Ly-  dy));
    % Txx  = -0*p0*sin(pi*xc  /(Lx-  dx)).*sin(pi*yc  /(Ly-  dy));
    % Tyy  = -0*p0*sin(pi*xc  /(Lx-  dx)).*sin(pi*yc  /(Ly-  dy));
    % Txy  = -0*p0*sin(pi*xVxy/(Lx-2*dx)).*sin(pi*yVxy/(Ly-2*dy));
    P        = gpuArray(P );
    Pf        = gpuArray(Pf );
Txx       = gpuArray(Txx );
Tyy       = gpuArray(Tyy  );
Tzz       = gpuArray(Tzz  );
    Exx       = Txx*0; Eyy = Tyy*0; Ezz = Tzz*0;
Exy       = P(2:end,2:end,:)*0; Exz = P(2:end,:,2:end)*0; Eyz = P(:,2:end,2:end)*0;
Exy       = gpuArray(Exy );
Eyz       = gpuArray(Eyz  );
Exz       = gpuArray(Exz  );
Exx       = gpuArray(Exx );
Eyy       = gpuArray(Eyy  );
Ezz       = gpuArray(Ezz  );
Txy       = gpuArray(Txy  );
Txz       = gpuArray(Txz  );
Tyz       = gpuArray(Tyz  );
dVx     = P(2:end,:,:)*0;
dVy     = P(:,2:end,:)*0;
dVz     = P(:,:,2:end)*0;
dVx     = gpuArray(dVx);
dVy     = gpuArray(dVy);
dVz     = gpuArray(dVz);
Vx        = gpuArray(Vx );
Vy        = gpuArray(Vy);
Vz       = gpuArray(Vz);
Qx        = gpuArray(Qx );
Qy        = gpuArray(Qy);
Qz       = gpuArray(Qz);
    for iter = 1:niter
        Exx                 = diff(Vx,1,1)/dx;
        Eyy                 = diff(Vy,1,2)/dy;
        Ezz                 = diff(Vz,1,3)/dy;
        Exy                 = 0.5*(diff(Vx(2:end-1,:,:),1,2)/dy...
            +                      diff(Vy(:,2:end-1,:),1,1)/dx);
        Exz  = 0.5*(diff(Vx(2:end-1,:,:),1,3)/dz ...
            +       diff(Vz(:,:,2:end-1),1,1)/dx);
        Eyz  = 0.5*(diff(Vy(:,2:end-1,:),1,3)/dz ...
            +       diff(Vz(:,:,2:end-1),1,2)/dy);
        divV                =  Exx + Eyy+ Ezz;
        divQ                =  diff(Qx,1,1)/dx  + diff(Qy,1,2)/dy+ diff(Qz,1,3)/dz;
        dP                  =0;% -Kdt*divV;
        Pold = P;
        P                   = (P   - Kdt.*(divV + 0.1.*divQ) )./(1 + Kr);
        Pf                  = (Pf  - Kdt.*(0.1.*divV + 0.5.*divQ))./(1 + Kr);
        dP = Pold - P;
        Txx                 = (Txx + 2*Gdt*(Exx-1*divV/3) )./(1+1*Gdt/eta+ Gr);
        Tyy                 = (Tyy + 2*Gdt*(Eyy-1*divV/3))./(1+1*Gdt/eta+ Gr);
        Tzz                 = (Tzz + 2*Gdt*(Ezz - 1/3.*divV))./(1 +      1*Gdt./eta  +         Gr );
        Txy(2:end-1,2:end-1, :)                 = (Txy(2:end-1,2:end-1, :) + 2*Gdt*Exy)./(1+0*Gdt/eta+ Gr);
        Txz(2:end-1, :,2:end-1)                 = (Txz(2:end-1, :,2:end-1) + 2*Gdt*Exz)./(1+0*Gdt/eta+ Gr);
        Tyz( :,2:end-1,2:end-1)                 = (Tyz( :,2:end-1,2:end-1) + 2*Gdt*Eyz)./(1+0*Gdt/eta+ Gr);

         Qxold = Qx;
        Qx(2:end-1,2:end-1,2:end-1) = Qx(2:end-1,2:end-1,2:end-1) + (-Qx(2:end-1,2:end-1,2:end-1) -  (k_etaf).*(diff(Pf(:,2:end-1,2:end-1),1,1)/dx         ))./(1 +  (k_etaf.*rho_dt));
         dQx = Qxold - Qx;
        Qy(2:end-1,2:end-1,2:end-1) = Qy(2:end-1,2:end-1,2:end-1) + (-Qy(2:end-1,2:end-1,2:end-1) -  (k_etaf).*(diff(Pf(2:end-1,:,2:end-1),1,2)/dy         ))./(1 +  (k_etaf.*rho_dt));
         
        Qz(2:end-1,2:end-1,2:end-1) = Qz(2:end-1,2:end-1,2:end-1) + (-Qz(2:end-1,2:end-1,2:end-1) -  (k_etaf).*(diff(Pf(2:end-1,2:end-1,:),1,3)/dz         ))./(1 +  (k_etaf.*rho_dt));

        dVx = (diff(Txx - P,1,1)/dx + diff(Txy(2:end-1,:,:),1,2)/dy + diff(Txz(2:end-1,:,:),1,3)/dz).*   (dt_rho);
        dVy = (diff(Tyy - P,1,2)/dy + diff(Txy(:,2:end-1,:),1,1)/dx + diff(Tyz(:,2:end-1,:),1,3)/dz).*   (dt_rho);
        dVz = (diff(Tzz - P,1,3)/dz + diff(Txz(:,:,2:end-1),1,1)/dx + diff(Tyz(:,:,2:end-1),1,2)/dy).*   (dt_rho);

        Vx(2:end-1,2:end-1,2:end-1) = Vx(2:end-1,2:end-1,2:end-1) + dVx(:,2:end-1,2:end-1);
        Vy(2:end-1,2:end-1,2:end-1) = Vy(2:end-1,2:end-1,2:end-1) + dVy(2:end-1,:,2:end-1);
        Vz(2:end-1,2:end-1,2:end-1) = Vz(2:end-1,2:end-1,2:end-1) + dVz(2:end-1,2:end-1,:);
        %ABS = diff(- P  + Txx,1,1)/dx;
        % Vy(:,[1 end],:)       = Vy(:,[2 end-1],:);
        % Vx([1 end],:,:)       = Vx([2 end-1],:,:);
        % Vz(:,:,[1 end])       = Vz(:,:,[2 end-1]);
        % Qy(:,[1 end],:)       = Qy(:,[2 end-1],:);
        % Qx([1 end],:,:)       = Qx([2 end-1],:,:);
        % Qz(:,:,[1 end])       = Qz(:,:,[2 end-1]);
        if mod(iter,20) == 0
        %abs_err = [max(abs(Vx(:)))  max(abs(Vy(:)))  0*max(abs(divV(:)))];
        %rel_err = [max(abs(dVx(:))) max(abs(dVy(:))) 0*max(abs(dP(:)))];
        abs_err =  [ max(abs(dQx(:)))];
        rel_err = [max(abs(dP(:)))];
        if max(abs_err) < abstol && max(rel_err) < reltol;iters(irun) = iter/nx;break;end
        %if max(rel_err) < reltol;iters(irun) = iter/nx;break;end
         %if max(abs_err(:)) < 0.01;iters(irun) = iter/nx;break;end
        if any(isnan(Vx),'all');iters(irun) = inf;break;end
        end
        if mod(iter,125*nx) == 0
            sgtitle(irun)
            subplot(221);imagesc(Vx(:,:,fix(nz/2)));axis image;colorbar
            subplot(222);imagesc(Vy(:,:,fix(nz/2)));axis image;colorbar
            subplot(223);imagesc(divV(:,:,fix(nz/2)));axis image;colorbar
            subplot(224);semilogy(iter/nx,abs_err,'d');hold on
            drawnow
        end
    end
    abs_err
    rel_err
    %subplot(224);hold off
end
R_e_exact    = R_e_opt*linspace(0.5,1.5,501);

Maximum = iters/nx; [find, find2] = min(Maximum(:)) ;
Reopt_num = R_e(find2)
figure(2);clf;
plot(R_e ,iters ,  'o','MarkerSize',10,'LineWidth',1.5); hold on;
plot( [2.9 2.9],[5 25],'LineWidth',3);
xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ {n}_\textrm{iter}/n_x$ (-)','Interpreter','latex'  );
legend('Numerical solution', '$   {\mathrm{St}}_\textrm{opt} = 2.9     $ ' ,'Interpreter','latex');
title('3D numerical simulation: poroelasticity');
grid on;
drawnow

if 2>1; return; end


lambda       = 0*R_e_exact;
for id = 1:numel(R_e_exact)
    K_G = K_G_opt;
    Pi  = pi;
    R_e2 = R_e_exact(id);
    cg = R_e_exact(id);
    % lambda(id) = -max(real(roots([1 ...
    %     3*R_e_exact(id) ...
    %     (2*K_G_opt*pi^2 + 6*pi^2 + 3*R_e_exact(id)^2) ...
    %     (R_e_exact(id)*(2*K_G_opt*pi^2 + 4*pi^2) + 2*pi^2*K_G_opt*R_e_exact(id) + (2*K_G_opt*pi^2 + 4*pi^2 + R_e_exact(id)^2)*R_e_exact(id) + 4*pi^2*R_e_exact(id)) ...
    %     (2*R_e_exact(id)^2*pi^2*K_G_opt + (R_e_exact(id)*(2*K_G_opt*pi^2 + 4*pi^2) + 2*pi^2*K_G_opt*R_e_exact(id))*R_e_exact(id) + 2*(2*K_G_opt*pi^2 + 4*pi^2 + R_e_exact(id)^2)*pi^2) ...
    %     (2*R_e_exact(id)^3*pi^2*K_G_opt + 2*(R_e_exact(id)*(2*K_G_opt*pi^2 + 4*pi^2) + 2*pi^2*K_G_opt*R_e_exact(id))*pi^2) ...
    %     4*R_e_exact(id)^2*pi^4*K_G_opt])));
    % lambda(id) = -max(real(roots([1 ...
    %     (6*R_e2)/7 + (3*R_e2*(K_G + 1))/7 ...
    %     (9*R_e2^2*(K_G + 1))/49 + (9*K_G*R_e2^2)/49 + (6*Pi^2*(K_G + 2))/7 + 486*((49*R_e2)/54 + (49*R_e2*(K_G + 1))/54)*R_e2/2401 + (6*Pi^2)/7 ...
    %     (162*R_e2*(K_G*R_e2^2/6 + (7*Pi^2*(K_G + 2))/9))/343 + (54*Pi^2*K_G*R_e2)/49 + 486*((7*R_e2^2*(K_G + 1))/18 + (7*K_G*R_e2^2)/18 + (49*Pi^2*(K_G + 2))/27)*R_e2/2401 + 972*((49*R_e2)/54 + (49*R_e2*(K_G + 1))/54)*Pi^2/2401 ...
    %     (162*Pi^2*K_G*R_e2^2)/343 + 486*(R_e2*(K_G*R_e2^2/6 + (7*Pi^2*(K_G + 2))/9) + (7*Pi^2*K_G*R_e2)/3)*R_e2/2401 + 972*((7*R_e2^2*(K_G + 1))/18 + (7*K_G*R_e2^2)/18 + (49*Pi^2*(K_G + 2))/27)*Pi^2/2401 ...
    %     (486*Pi^2*K_G*R_e2^3)/2401 + 972*(R_e2*(K_G*R_e2^2/6 + (7*Pi^2*(K_G + 2))/9) + (7*Pi^2*K_G*R_e2)/3)*Pi^2/2401 ...
    %     (972*Pi^4*K_G*R_e2^2)/2401])));


%Warning, the following variable name replacements were made: R_e~ -> cg, cg -> cg1
cg10 = 0.63e2 * cg ^ 4 * pi ^ 6;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg0 = 0.9e1 * cg ^ 5 * pi ^ 4 + 0.7e1 * (0.36e2 * cg ^ 3 * pi ^ 4 + 0.6e1 * cg ^ 5 * pi ^ 2) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg1 = 0.9e1 * cg ^ 4 * pi ^ 4 + (0.36e2 * cg ^ 3 * pi ^ 4 + 0.6e1 * cg ^ 5 * pi ^ 2) * cg + 0.7e1 * (cg ^ 4 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.24e2 * cg ^ 4 * pi ^ 2 + 0.54e2 * cg ^ 2 * pi ^ 4) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg2 = 0.36e2 * cg ^ 3 * pi ^ 4 + 0.6e1 * cg ^ 5 * pi ^ 2 + (cg ^ 4 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.24e2 * cg ^ 4 * pi ^ 2 + 0.54e2 * cg ^ 2 * pi ^ 4) * cg + 0.7e1 * (0.2e1 * cg ^ 5 + 0.4e1 * cg ^ 3 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.36e2 * cg ^ 3 * pi ^ 2 + 0.36e2 * cg * pi ^ 4) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg3 = cg ^ 4 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.24e2 * cg ^ 4 * pi ^ 2 + 0.54e2 * cg ^ 2 * pi ^ 4 + (0.2e1 * cg ^ 5 + 0.4e1 * cg ^ 3 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.36e2 * cg ^ 3 * pi ^ 2 + 0.36e2 * cg * pi ^ 4) * cg + 0.7e1 * (0.9e1 * cg ^ 4 + 0.6e1 * cg ^ 2 * (0.6e1 * pi ^ 2 + cg ^ 2) + 0.24e2 * cg ^ 2 * pi ^ 2 + 0.9e1 * pi ^ 4) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg4 = (2 * cg ^ 5) + 0.4e1 * (cg ^ 3) * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.36e2 * (cg ^ 3) * pi ^ 2 + 0.36e2 * cg * pi ^ 4 + ((9 * cg ^ 4) + 0.6e1 * (cg ^ 2) * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.24e2 * (cg ^ 2) * pi ^ 2 + 0.9e1 * pi ^ 4) * cg + 0.7e1 * ((16 * cg ^ 3) + 0.4e1 * cg * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.6e1 * pi ^ 2 * cg) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg5 = (9 * cg ^ 4) + 0.6e1 * (cg ^ 2) * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.24e2 * (cg ^ 2) * pi ^ 2 + 0.9e1 * pi ^ 4 + ((16 * cg ^ 3) + 0.4e1 * cg * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.6e1 * pi ^ 2 * cg) * cg + 0.7e1 * (0.6e1 * pi ^ 2 + (15 * cg ^ 2)) * pi ^ 2;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg6 = (16 * cg ^ 3) + 0.4e1 * cg * (0.6e1 * pi ^ 2 + (cg ^ 2)) + 0.48e2 * pi ^ 2 * cg + (0.6e1 * pi ^ 2 + (15 * cg ^ 2)) * cg;

%Warning, the following variable name replacements were made: R_e~ -> cg
cg7 = 0.13e2 * pi ^ 2 + (21 * cg ^ 2);

%Warning, the following variable name replacements were made: R_e~ -> cg
cg8 = 7 * cg;
cg9 = 1;



A = [cg9 cg8 cg7 cg6 cg5 cg4 cg3 cg2 cg1 cg0 cg10];
        lambda(id) = -max(real(roots( (A))));

end
% dtau = dx*CFL/Vs
% exp(-lambda*niter*dtau*Vs/Lx) = abstol
% lambda*niter*dx*CFL/Lx       = -log(abstol)
iters_exact = -log(abstol)./lambda/CFL/dx/nx;
plot(R_e_exact,iters_exact,'r-',R_e,iters,'-ko','LineWidth',1);
xline(R_e_opt     ,'k--','LineWidth',1.2); hold on;


for ipar = 1:12
    par   = 3+ipar/2;
    %R_e   = par;
    R_e       = R_e_opt*linspace(0.5,2.5,12); G=G0;
    K     = 1*G;%*K_G
    rho   = R_e(ipar)^2*eta^2/((1*K+4/3*G)*Lx^2); %rho^2*G/rho*Lx^2/eta^2 = R_e^2
    dt    = 1.*dx/sqrt((1*K+4/3*G)/rho);
    Vs    = sqrt((1*K+4/3*G)/rho);
    %Vs = dx;
fun    = 1; nt = 1e6; omega=1;
    for it = 1:nt  
        fun_old=fun;
        %a1 = 1; a2= R_e; a3= pi^2*omega^2 + K_G*pi^2*omega^2; a4= K_G*pi^2*R_e*omega^2;
        %a1 = 1; a2= 36/35*R_e; a3= 27/35*pi^2*omega^2 + (288*R_e^2)/1225; a4= (72*pi^2*R_e*omega^2)/245;
        
        a1 = 2.719176724*R_e(ipar)*omega^2; 
        a2= 8.459660917*omega^2 + 0.09183673469*R_e(ipar)^2; 
        a3= 0.6428571429*R_e(ipar); 
        a4= 1;
        A = [a1 a2 a3 a4];
        Pol2        = roots( flip(A));
        lambda       = real(Pol2);
        fun         = exp(  lambda(3)*Vs*it*dt ./Lx     ) ; %+ 0*pi*omega.*x.*1i./Lx
 
        %fun2   = exp((alph*Vs*dt*it + pi*omega*x*I)/Lx);
        if it == 1, mfun        = max(abs(   exp( lambda(3)*Vs*it*dt./Lx   )  ));   end % + 0*pi*omega.*x.*1i./Lx 

        err         = fun - fun_old;
        merr        = max(abs(fun)); 
        if merr < 1/1*1e-8*mfun,break,end  
    end
    %Max_err(ipar)   = merr;
    iters(ipar)     = it;
    %lambtest(ipar)  =lambda;
end

 hold on; plot(R_e ,iters/nx, 'd--','LineWidth',3);  hold on;
