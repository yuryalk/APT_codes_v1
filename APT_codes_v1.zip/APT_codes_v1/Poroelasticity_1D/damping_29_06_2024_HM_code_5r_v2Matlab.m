clear, figure(1), clf
%physics
Lx    = 1;
w     = 1*pi;
u0    = 1;
eta   = 1e0;
%numerics
nx    = 201;
nt    = 2e4;
K_G   = 1;
G     = 1;
%preprocessing
dx    = Lx/(nx-1);
x     = 0:dx:Lx;
iters1 = 0;
ipars1 = 0;
 
%%
for ipar = 1:22
    par   = 0.1+ipar/2;
    St   = par;
    K     = 1*K_G*G;
    dt    = 1;
    % initial
    V     = 1*u0*sin(1*w*x/Lx);
    P     = 0*diff(V);
    Pf    = P;
    Q     = 1*u0*sin(1*w*x/Lx);
    tau   = P*0;
    %action
    CFL      = 1.0/1.001;
    Vpdt     = dx*CFL;
    G0       = 1;
    eta      = 1e1;
    G0x       = 1+4/3*G0; % 4/3*G0 = G0x-1 => G0 = 3/4*(G0x-1)
    eta_ve   = 1./(1./eta*0 + 1./(G0x.*dt));
    dt_rho   = Vpdt.*Lx./St./eta_ve;
    dt_rho = dt_rho*1;
    dt_rho2  = dt_rho;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K.*dt);
    Kf       = K/1;
    Kfdt      = K_G/1.*Gdt; %Kdt - numer;
    Kfr       = Kfdt./(Kf.*dt);
    tau_old  = tau*0;
    P_old    = P*0;
    Pf_old   = Pf*0;
    B    = 0.1;
    B_alph       = 0.5;
    k_etaf   = 1000.0;
    for it = 1:nt
        P          = (P + P_old.*Kr         - Kdt.* (diff(V)/dx       + B.*diff(Q)/dx))./(1 + Kr)   ;
        Pf         = (Pf + Pf_old.*Kfr      - Kfdt.*(B.*diff(V)/dx + B_alph*diff(Q)/dx       ))./(1 + Kr)   ;   
        tau        = (tau+tau_old.*Gr + 2* Gdt.*( (diff(V)/dx - diff(V)/dx/3)  ))./(1 + 0*Gdt./eta + Gr); 
        V(2:end-1) = V(2:end-1)      + dt_rho*diff(-P + tau)/dx;
        Q(2:end-1) =  Q(2:end-1) + ( - Q(2:end-1) -k_etaf.*diff(+Pf  )/dx )./(1+1./dt_rho2.*k_etaf);
        if mod(it,10000) == 0
            time    = it*dt;            
            subplot(2,2,1),loglog(time, max(abs(V)), 'd')
            title(max(abs(V))),hold on
            subplot(2,2,2),plot(x, V, 'd'),title(it),axis([0 Lx -u0 u0])
            subplot(2,2,3),loglog(time, max(abs(P)), 'd'),hold on
            drawnow
        end
        if max(abs(V)) + max(abs(tau)) + max(abs(P)) < 1e-11,break;end
    end
    iters1(ipar) = it;
    ipars1(ipar) = par;
    subplot(2,2,4),plot(ipars1,iters1/nx,'-s'),title(min(iters1/nx)),drawnow
    [val1, val2] = min(iters1/nx);
    Re_opt_num =   0.1+(val2-0)/2 ;
end
%%
omega = 1; iparmax = 20;
for ipar = 1:iparmax
    par   = 0.1+ipar/2;
    St   = par;
    K     = K_G*G;
    %eta_ve = eta;
    eta_ve   = 1./(1./eta*0 + 1./(G0.*dt));
    rho   = St^2*eta_ve^2/((1*K+4/3*G)*Lx^2);
    dt    = 1.*dx/sqrt((1*K+4/3*G)/rho);
    Vs    = sqrt((1*K+4/3*G)/rho);     %dt = 1;     %Vs = dx;
fun    = 1; k_eta = 1*k_etaf;
    for it = 1:nt  
        fun_old=fun;      

cg = 0.4934802205e-1 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 2 * St + 0.2435227279e3 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 4 * St;
cg0 = 0.5000000001e-2 / (0.25e-4 + 0.1166666666e2 * St) * St ^ 2 + 0.1398193958e3 / (0.25e-4 + 0.1166666666e2 * St) * St ^ 2 * omega ^ 2 + 0.2467401102e-3 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 2 * St + 0.4934802204e-1 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 2;
cg1 = 0.2500000000e-4 / (0.25e-4 + 0.1166666666e2 * St) * St ^ 2 + 0.1166666667e2 / (0.25e-4 + 0.1166666666e2 * St) * St ^ 3 + 0.1000000000e-1 / (0.25e-4 + 0.1166666666e2 * St) * St + 0.1398193957e3 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 2 * St + 0.2467401102e-3 / (0.25e-4 + 0.1166666666e2 * St) * omega ^ 2;
cg2 = 0.5000000000e-4 / (0.25e-4 + 0.1166666666e2 * St) * St + 0.2333333333e2 / (0.25e-4 + 0.1166666666e2 * St) * St ^ 2 + 0.5000000000e-2 / (0.25e-4 + 0.1166666666e2 * St);
cg3 = 0.2500000000e-4 / (0.25e-4 + 0.1166666666e2 * St) + 0.1166666666e2 / (0.25e-4 + 0.1166666666e2 * St) * St;
cg4 = 0;



A = [ cg4 cg3 cg2 cg1 cg0  cg];
        %A = [a0 a1 a2 a3 a4 a5];
        rt = 1;
        Pol2        = roots( (A));
        lambda       =      max(real(Pol2));
        fun         = exp(  lambda(rt)*Vs*it*dt ./Lx     ) ; 
        if it == 1, mfun        = max(abs(   exp( lambda(rt)*Vs*it*dt./Lx   )  ));   end  
        err         = fun - fun_old;
        merr        = max(abs(fun)); 
        if merr < 1.5*1e-12*mfun,break,end  
    end
    iters(ipar)     = it;
end
subplot(2,2,4),hold on; plot( 0.1+[1:iparmax]/2 ,iters/nx, 'd--','LineWidth',3);  hold on;
Re_opt =   2.908695919 +0*sqrt((56*pi^2)/3)
plot( [Re_opt Re_opt],[5 15],'LineWidth',3); hold on;
plot( [Re_opt_num Re_opt_num],[5 15],'LineWidth',2);

figure(2);clf
plot(ipars1 ,iters1 /nx,'-x','LineWidth',1.5 ) 
hold on; plot( 0.1+[1:iparmax]/2 ,iters/nx, 'o','MarkerSize',10,'LineWidth',1.5);  hold on;
%Re_opt =  0*14.66076508 +2*sqrt(42)/7*pi  
plot( [Re_opt Re_opt],[5 25],'LineWidth',3);
plot( [Re_opt_num Re_opt_num],[5 25],'--','LineWidth',3);
xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ {n}_\textrm{iter}/n_x$ (-)','Interpreter','latex'  );
legend('Numerical solution','Analytical solution','$   {\mathrm{St}}_\textrm{opt} = 2.9     $ ',...
    '$   {\mathrm{St}}_\textrm{opt} - \textrm{numerical}  $ ','Interpreter','latex');
grid on;
drawnow


        