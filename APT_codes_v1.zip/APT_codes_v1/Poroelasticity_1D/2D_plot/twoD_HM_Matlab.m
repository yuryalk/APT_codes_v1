clear;figure(1);clf;colormap jet;
Re         = linspace(1,15,124);
k_eta0        =  (linspace(0.001,15,124));
k_eta0        =  (logspace(-4,4,124));
omega      = 1;
Re_opt     = 22.08255701;
G_K_opt    = 1;
[St2,k_eta1] = ndgrid(Re,k_eta0);
alpha      = 0*St2;
G_K_line   = linspace(G_K_opt,k_eta0(end),100);
%Re_line    = sqrt(2)*sqrt(G_K_line.*(G_K_line.^2*pi^2 + 20*G_K_line*pi^2 - 8*pi^2 + sqrt(G_K_line.^4*pi^4 - 24*G_K_line.^3*pi^4 + 192*G_K_line.^2*pi^4 - 512*G_K_line*pi^4)))*omega./(4*G_K_line);
for ip = 1:numel(St2)
    St = St2(ip); Pi = pi;     k_eta = k_eta1(ip);

cg = 0.4229830460e1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St * omega ^ 2 + 0.2087337668e2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St * k_eta * omega ^ 4;
cg0 = 0.1198451964e2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St ^ 2 * k_eta * omega ^ 2 + 0.2114915229e-1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St * omega ^ 2 + 0.4285714285e0 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St ^ 2 + 0.4229830459e1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * omega ^ 2;
cg1 = 0.1000000000e1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St ^ 3 * k_eta + 0.2142857142e-2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St ^ 2 + 0.1198451963e2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St * k_eta * omega ^ 2 + 0.8571428569e0 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St + 0.2114915229e-1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * omega ^ 2;
cg2 = 0.1999999999e1 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St ^ 2 * k_eta + 0.4285714284e-2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St + 0.4285714284e0 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2);
cg3 = 0.9999999991e0 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2) * St * k_eta + 0.2142857142e-2 / (0.9999999991e0 * St * k_eta + 0.2142857142e-2);
cg4 = 0;

A = [ cg4 cg3 cg2 cg1 cg0  cg];
rt = 1;
        Pol2        = roots( (A));
        alpha(ip)       =      max(real(Pol2));

    %alpha(ip) = max(real(roots([cg2  ,  cg1   ,  cg0  ,  cg])));
end
contourf(St2,log10(k_eta1),alpha,20,'LineWidth',1);cb=colorbar;axis square tight
 [~,idx] = min(alpha,[],'all','linear');
hold on
% plot(Re_line,G_K_line,'w--','LineWidth',3);
%plot(Re_opt,G_K_opt,'wo','MarkerSize',7,'MarkerFaceColor','w')
plot(2.908695919,log10(1000),'wo','MarkerSize',7,'MarkerFaceColor','w')
 plot(2*pi,log10(0.001),'wo','MarkerSize',7,'MarkerFaceColor','w')
% plot(Re2(idx),1./K_G2(idx),'m+','MarkerSize',10,'LineWidth',2)
hold off
%title('$\widetilde{\mathrm{Re}}_\mathrm{opt}  = \frac{2}{3} \,\sqrt{42}\, \pi \approx 13.57$ ','Interpreter','latex');
xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ \log_{10}{(I_2)}$ (-)','Interpreter','latex'  );
title(cb,'$ {n}_\textrm{iter}/n_x$  (-)','FontSize',16,'Rotation',0,'Interpreter','latex')
% xlabel('\it Re');
% ylabel('\it G/K')
% cb.Label.String   = '\alpha';
% cb.Label.FontSize = 14;
% set(gca,'FontSize',12)
% exportgraphics(gcf,'optimal_params_stokes2.png','Resolution',300)