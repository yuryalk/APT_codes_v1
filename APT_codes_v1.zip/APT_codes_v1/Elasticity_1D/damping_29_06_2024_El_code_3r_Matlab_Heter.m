clear; clf;clc;
tic;%opengl software
h = figure(1); clf;clear,format long; format compact; 
% non dim
Lx          = 1;
G0          = 1 ;
K0          = 1 ;
G1          = 0.1 ;
K1          = 0.1 ;
rho0        = 1;
fi = 0.5;
% numerical
nx          = 1000;
G          = G0 + zeros(nx,1);
K          = K0 + zeros(nx,1);
dx          = Lx/(nx-1);
x           = (-Lx/2:dx:Lx/2)';
x2          = (-(Lx+dx)/2:dx:(Lx+dx)/2)';
CFL         = 1;
nt          = 1;
niter       = 5*nx;
nout        = 0.2*nx;
eiter       = 1e-9;
damp        =  pi;
K_G         = 1;

% layers
layer_thkness = fix(nx/10);
for i=1:2*layer_thkness:nx+layer_thkness*0
    G(i:i+layer_thkness-1 )=G1;
    K( i:i+layer_thkness-1 )=K1;
end
%
% G = G0-G;
% K = K0-K;
plot(K);

Vp         = sqrt( (K0+4/3*G0)/rho0 );
dt         = CFL * dx*1/Vp;
dt = 1;

dt2    = 1;                           
rho0  = dt2^2/CFL^2/dx^2*(max(K0,K1)+4/3*max(G0, G1));

% init cond
lamx        = 0.02;
Pt          = 0*exp(-(x/lamx).^2); 
tau_xx      = 0*exp(-(x/lamx).^2); 
Vx          = zeros(nx+1,1);
error       = zeros(niter,1);

Pt2          = Pt; 
tau_xx2      = tau_xx; 
Vx2          = zeros(nx+1,1);
error2       = zeros(niter,1);
Ux2          = 0*Vx2;

for it = 1:nt  
    St      = 2*pi .*min(K1,G0)/fi ;
    eta     = 1e10;
    Vpdt     = dx*CFL;
    H        =  (K0+4/3*G0).*dt;
    dt_rho   = Vpdt.*Lx./St./H;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K.*dt);

    Vx(1)         = 1e+0;     Vx(end)       = 0;
    %Vx = linspace(Vx(1),0,nx+1)';
    Vx2(1)         = 1e+0;     Vx2(end)       = 0;
    %Vx2 = linspace(Vx2(1),0,nx+1)';
    for iter = 1:niter
    
    div_Vs        = diff(Vx,1,1)/dx;    
    Pt            = (Pt   - Kdt.*div_Vs)./(1 + Kr);
    tau_xx        = (tau_xx  + 2*Gdt.*(div_Vs  - div_Vs/3))./(1 +     0*Gdt./eta + Gr);
    dVx           = diff(-Pt+tau_xx,1,1)/dx.*dt_rho;
    Vx(2:end-1)   = Vx(2:end-1)     +     dVx  ; 
    error(iter)   = (max(abs(dVx(:)))/Lx)./max(abs(Vx(:)));

    
    div_Vs2        = diff(Vx2,1,1)/dx;    
    Pt2            = (Pt2   - K.*div_Vs2*dt2);
    tau_xx2        = (tau_xx2  + G.*2.*dt2.*(div_Vs2  - div_Vs2/3));
    dVx2           = diff(-Pt2+tau_xx2,1,1)/dx.*dt2./rho0;
    Vx2(2:end-1)   = (Vx2(2:end-1)     +     dVx2  )./(1+0*Gdt+1*damp./nx); 
    Ux2             = Ux2 + Vx2*dt;
    error2(iter)   = max(abs(dVx2(:)))/Lx;  
    if mod(iter,nout)==0 
        subplot(3,1,1), plot(x,G,'k-','linewidth',1.5),    
         title('Elastic moduli, K=G (-)'),  
        xlabel( 'x (-)'  ); ylabel( 'Amplitude (-)'  );hold off
        subplot(3,1,2), plot(x,(Vx(2:end) + Vx(1:end-1))/2,'k-','linewidth',1.5),    
        hold on; plot( x,(Vx2(2:end) + Vx2(1:end-1))/2,'g--','linewidth',1.5),title('Velocity, v_x (-)'),  
        xlabel( 'x (-)'  ); ylabel( 'Amplitude (-)'  );hold off
        subplot(3,1,3), plot(diff(Vx(2:end) + Vx(1:end-1))/2,'k-','linewidth',1.5),    
        hold on; plot( diff(Vx2(2:end) + Vx2(1:end-1))/2,'g--','linewidth',1.5),title(' \partial v_x / \partial x (-)'),  
        xlabel( 'x (-)'  ); ylabel( 'Amplitude (-)'  );hold off
        drawnow;
    end
    %if error(iter) < eiter,break,end 
    end
end
subplot(3,1,2), legend('Damping scheme 2','Damping scheme 1')
error_print_Method1 = error(iter)
error_print2_Method_old = error2(iter)

l = linspace(0,Vx2(1),nx+1);
sum_x2 = sum(l(:));

Sxx = (-Pt(:)+tau_xx(:)); Av_Sxx = sum(Sxx(:));
Exx = diff(Vx,1,1)/dx; Av_Exx = sum(Exx(:));
 
Sxx2 = (-Pt2(:)+tau_xx2(:)); Av_Sxx2 = sum(Sxx2(:));
Exx2 = diff(Ux2,1,1)/dx; Av_Exx2 = sum(Exx2(:));
 
%%
%fi = 0.5;
fi =1-fi;
SxxIN =  Sxx(:,:);  
ExxIN =  Exx(:,1:end-0);  
Av_Sxx = sum(SxxIN(:)); Av_Exx = sum(ExxIN(:)); 
Gb1 = G0; Kb1 = K0;   Lamb1 = Kb1-2/3*Gb1;
Gb2 = G1; Kb2 = K1; Lamb2 = Kb2-2/3*Gb2;
Average_K =  fi*(Lamb1 + 2*Gb1) + (1-fi)*((Lamb2 + 2*Gb2));
Average_S =  ( fi*1./(Lamb1 + 2*Gb1) + (1-fi)*1/((Lamb2 + 2*Gb2)) ).^(-1);
C33_bK_an = Average_K;
C = Average_S;
A1 = fi* 4*Gb1*(Lamb1 + Gb1)./(Lamb1 + 2*Gb1) + (1-fi)*4*Gb2*(Lamb2 + Gb2)./(Lamb2 + 2*Gb2);
A2 = (   fi*1./(Lamb1 + 2*Gb1) + (1-fi)*1/((Lamb2 + 2*Gb2))  ).^(-1);
A3 = (   fi*Lamb1./(Lamb1 + 2*Gb1) + (1-fi)*Lamb2/((Lamb2 + 2*Gb2))  ).^(2);
A = A1 + A2 .* A3;
B = A2 * A3 + fi* 2*Gb1*Lamb1./(Lamb1 + 2*Gb1) + (1-fi)*2*Gb2*Lamb2./(Lamb2 + 2*Gb2);
F = A2*sqrt(A3);
Kaver = (2*A+ C + 2*B +4*F )/9;
Mu = (A-B)/2;

Gav   = (fi*1/Gb1 + (1-fi)*1/Gb2)^(-1);
Gav   = (fi*Gb1 + (1-fi)*Gb2);

C33 = (Av_Sxx)./(Av_Exx);
C33_2 = (Av_Sxx2)./(Av_Exx2);
K_ple =C33;% (C33-4/3*Gav)
K_3d = 4*K_ple*Gav/( 9*Gav - 3*K_ple);
K_3d = K_ple - Gav/3;
C33_3d = K_3d+4/3*Gav;

diff_An_Num_Percent = (A-C33)/A*100;
diff_An_Num_Percent_Method1 = (C-C33)/C*100
diff_An_Num_Percent_Method_old = (C-C33_2)/C*100
%%
zzzz = 1;





