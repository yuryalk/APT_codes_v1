clear, figure(1), clf
%physics
Lx    = 1;
w     = pi;
u0    = 1;
eta   = 1*1e0;
nx_init = 100;

K_G   = 1+0*pi+0*1/8;

iters = 0;
ipars = 0;
for ipar = 1:5
    %numerics
    nx    = nx_init.*2*ipar;
    nt    =5*nx;
    %preprocessing
    dx    = Lx/(nx-1);
    x     = 0:dx:Lx+dx;
    G0          = 1 ;
    K0          = 1 ;
    G1          = 0.10 ;
    K1          = 0.10 ;
    G          = G0 + zeros(nx,1)' ;
    K          = K0 + zeros(nx,1)' ;
    layer_thkness = fix(nx/(10*1));
    for i=1:2*layer_thkness:nx+layer_thkness*0
        G(i:i+layer_thkness-1 )=G1;
        K( i:i+layer_thkness-1 )=K1;
    end


    %par   = 0.01+ipar/4;
    fi = 0.5;
    Average_K = min(K1,G1)/fi;
    St   = 2*pi*Average_K;%par; 
    K     = 1*G; 
    dt       = 1;
    CFL      = 1/1.001;
    Vpdt     = dx*CFL;
    G0        = 1;
    G0x       = 1+4/3*G0; % 4/3*G0 = G0x-1 => G0 = 3/4*(G0x-1)
    eta_ve   = 1./(1./eta*0 + 1./(G0x.*dt));
    dt_rho   = Vpdt.*Lx./St./eta_ve;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K.*dt);
    % initial
    V     = 0*u0*sin(w*x/Lx);
    Pr    = 0*diff(V);
    V(1)  = 1e+0;     V(end)       = 0;
    tau   = Pr*0;
    for it = 1:nt
        Pr         = (Pr          - Kdt.*diff(V)/dx)./(1 + Kr)   ;  
        tau        = (tau + 2* Gdt.*( (diff(V)/dx - diff(V)/dx/3)  ))./(1 + 0*Gdt./eta + Gr); 
        dV            = dt_rho *diff(-Pr + tau)/dx;
        V(2:end-1) = V(2:end-1)      + dV ;
        error    = (max(abs(dV(:)))/Lx)./max(abs(V(:)));
        % if mod(it,100) == 0
        %     time    = it*dt;            
        %     subplot(2,2,1),loglog(time, max(abs(V)), 'd')
        %     title(max(abs(V))),hold on
        %     subplot(2,2,2),plot(x, V, 'd'),title(it),axis([0 Lx -u0 u0])
        %     subplot(2,2,3),loglog(time, max(abs(Pr)), 'd'),hold on
        %     drawnow
        % end
         if error < 1e-10,break;end
        
    end
    error_save(ipar) = error;
    iters1(ipar) = it;
    Sxx = (-Pr(:)+tau(:));  
    Exx = diff(V ,1,2)/dx; 
    fi =1-fi;
    SxxIN =  Sxx(:,:);  
    ExxIN =  Exx(:,1:end-0);  
    Av_Sxx = sum(SxxIN(:)); Av_Exx = sum(ExxIN(:)); 
    C33(ipar) = (Av_Sxx)./(Av_Exx);
    Gb1 = G0; Kb1 = K0;   Lamb1 = Kb1-2/3*Gb1;
    Gb2 = G1; Kb2 = K1; Lamb2 = Kb2-2/3*Gb2;
    Average_S =  ( fi*1./(Lamb1 + 2*Gb1) + (1-fi)*1/((Lamb2 + 2*Gb2)) ).^(-1);
    C = Average_S;
    diff_An_Num_Percent_Method1(ipar) =  (C-C33(ipar)) ; %/C*100
end
 
figure(1);clf
K_sat_AN_K_satN  = abs(C-C33 );
Vx_dif_gl0 = 1./C33 .*abs(K_sat_AN_K_satN)  ;
plot( log10(nx_init.*2*[1:ipar]),log10(Vx_dif_gl0),'-x','LineWidth',1.5 ) ;hold on;
 
fi = 0.5;
Average_K = min(K1,G1)/fi;
 
Re_opt =  2*pi ;
Re_opt2 = 2*pi*Average_K;
 
DX = nx_init.*2*[1:ipar]; %Vx_dif_gl0 = diff_An_Num_Percent_Method1;
P1  = polyfit(log10(DX(:)),log10(abs(Vx_dif_gl0(:))),1);
L1  = log10(DX(:))*P1(1) + P1(2);
plot(log10(DX(:)),L1,'-','color',[0.2000 0.20 0.20],'linewidth',1.5),hold on
text(log10(DX(1))*1.01,log10(abs(Vx_dif_gl0(3)))*1.0,...
   ['slope = ',num2str(P1(1)),' '],'interpreter', 'latex',...
   'FontSize', 14,'color',[0.2000 0.20 0.20])
legend('$log_{10}( ||H^{err}||_1)$','Best-fit polynomial','interpreter', 'latex')


xlabel( '$ log_{10}(n_x)$ (-)','Interpreter','latex'  ); 
ylabel( '$log_{10}( ||H^{err}||_1)$ (-)','Interpreter','latex'  );
% legend('Numerical solution', ...
%     '$   {\mathrm{St}}_\textrm{opt} =2  \pi     $ ',...
%     '$   {\mathrm{St}}_\textrm{opt}^h = 2  \pi \cdot A     $ ','Interpreter','latex');
grid on;
drawnow




       