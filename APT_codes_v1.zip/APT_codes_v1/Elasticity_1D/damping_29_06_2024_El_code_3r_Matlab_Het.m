clear, figure(1), clf
%physics
Lx    = 1;
w     = pi;
u0    = 1;
eta   = 1*1e0;
%numerics
nx    = 400;
nt    = 1e6;
K_G   = 1+0*pi+0*1/8;
G     = 1;

G0          = 1 ;
K0          = 1 ;
G1          = 0.10 ;
K1          = 0.10 ;
G          = G0 + zeros(nx,1)' ;
K          = K0 + zeros(nx,1)' ;
layer_thkness = fix(nx/10);
for i=1:2*layer_thkness:nx+layer_thkness*0
    G(i:i+layer_thkness-1 )=G1;
    K( i:i+layer_thkness-1 )=K1;
end
%preprocessing
dx    = Lx/(nx-1);
x     = 0:dx:Lx+dx;
iters = 0;
ipars = 0;
for ipar = 1:25
    par   = 0.01+ipar/4;
    St   = par; 
    K     = 1*G; 
    dt       = 1;
    CFL      = 1/1.001;
    Vpdt     = dx*CFL;
    G0        = 1;
    G0x       = 1+4/3*G0; % 4/3*G0 = G0x-1 => G0 = 3/4*(G0x-1)
    eta_ve   = 1./(1./eta*0 + 1./(G0x.*dt));
    dt_rho   = Vpdt.*Lx./St./eta_ve;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K.*dt);
    % initial
    V     = 0*u0*sin(w*x/Lx);
    Pr    = 1*diff(V);
    tau   = Pr*0;
    V(1)         = 1e+0;     V(end)       = 0;
    for it = 1:nt
        Pr         = (Pr          - Kdt.*diff(V)/dx)./(1 + Kr)   ;  
        tau        = (tau + 2* Gdt.*( (diff(V)/dx - diff(V)/dx/3)  ))./(1 + 0*Gdt./eta + Gr); 
        dV            = dt_rho *diff(-Pr + tau)/dx;
        V(2:end-1) = V(2:end-1)      + dV ;
        error    = (max(abs(dV(:)))/Lx)./max(abs(V(:)));
        % if mod(it,10000) == 0
        %     time    = it*dt;            
        %     subplot(2,2,1),loglog(time, max(abs(V)), 'd')
        %     title(max(abs(V))),hold on
        %     subplot(2,2,2),plot(x, V, 'd'),title(it),axis([0 Lx -u0 u0])
        %     subplot(2,2,3),loglog(time, max(abs(Pr)), 'd'),hold on
        %     drawnow
        % end
        if error < 1e-9,break;end
    end
    iters1(ipar) = it;
    ipars1(ipar) = par;
    % subplot(2,2,4),plot(ipars1,iters1/nx,'-x'),title(min(iters1/nx)),drawnow
     Maximum = iters1/nx; [find, find2] = min(Maximum(:)) ;  
end
Reopt_num = ipars1(find2)
 
Re_opt = 2*pi
%plot( [Re_opt Re_opt],[5 15],'LineWidth',3);

figure(1);clf
plot(ipars1,iters1/nx,'-x','LineWidth',1.5 ) ;hold on;
%hold on; plot( 3+[1:iparmax]/1 ,iters/nx, 'o','MarkerSize',10,'LineWidth',1.5);  hold on;
fi = 0.5;
Average_K = min(K1,G1)/fi;
%Average_K =   ( fi*( (min(K1,G1) + 1*4/3*min(K1,G1)) + 1*(1-fi)*(K0 + 4/3* G0 ) ) );
Re_opt =  2*pi ;
Re_opt2 = 2*pi*Average_K;
plot( [Re_opt Re_opt],[5 15],'LineWidth',3);
plot( [Re_opt2 Re_opt2],[5 15],'LineWidth',3);
xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ {n}_\textrm{iter}/n_x$ (-)','Interpreter','latex'  );
legend('Numerical solution', ...
    '$   {\mathrm{St}}_\textrm{opt} =2  \pi     $ ',...
    '$   {\mathrm{St}}_\textrm{opt}^h = 2  \pi \cdot A     $ ','Interpreter','latex');
grid on;
drawnow




       