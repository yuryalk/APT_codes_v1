tic;%opengl software
h = figure(1); clf;clear,format long; format compact; 

Lx          = 1;
G0          = 1;
K0          = 1;
rho0        = 1;

nx          = 1000;
dx          = Lx/(nx-1);
x           = (-Lx/2:dx:Lx/2)';
x2          = (-(Lx+dx)/2:dx:(Lx+dx)/2)';
CFL         = 1;
nt          = 1;
niter       = 5*nx;
nout        = 0.1*nx;
eiter       = 1e-9;
damp        =  pi;
K_G         = 1;


Vp         = sqrt( (K0+4/3*G0)/rho0 );
dt         = CFL * dx*1/Vp;
dt = 1;

dt2    = 1;                           
rho0  = dt2^2/CFL^2/dx^2*(max(K0(:))+4/3*max(G0(:)));

lamx        = 0.02;
Pt          = 0*exp(-(x/lamx).^2); 
tau_xx      = 0*exp(-(x/lamx).^2); 
Vx          = zeros(nx+1,1);
error       = zeros(niter,1);

Pt2          = Pt; 
tau_xx2      = tau_xx; 
Vx2          = zeros(nx+1,1);
error2       = zeros(niter,1);
Ux2          = 0*Vx2;

for it = 1:nt  
    St      = 2*pi;
    eta     = 1e10;
    Vpdt     = dx*CFL;
    H        =  (K0+4/3*G0).*dt;
    dt_rho   = Vpdt.*Lx./St./H;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G0.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K0.*dt);

    for iter = 1:niter
    Vx(1)         = 1e-5;     Vx(end)       = 0;
    div_Vs        = diff(Vx,1,1)/dx;    
    Pt            = (Pt   - Kdt.*div_Vs)./(1 + Kr);
    tau_xx        = (tau_xx  + 2*Gdt.*(div_Vs  - div_Vs/3))./(1 +     0*Gdt./eta + Gr);
    dVx           = diff(-Pt+tau_xx,1,1)/dx.*dt_rho;
    Vx(2:end-1)   = Vx(2:end-1)     +     dVx  ; 
    Ux            =    Vx*dt; 
    %error(iter)   = (max(abs(dVx(:)))/Lx)./max(abs(Vx(:)));
    error(iter)   = max(abs(Vx(:)))/Lx;

    Vx2(1)         = 1e-5;     Vx2(end)       = 0;
    div_Vs2        = diff(Vx2,1,1)/dx;    
    Pt2            = (Pt2   - K0.*div_Vs2*dt2);
    tau_xx2        = (tau_xx2  + G0.*2.*dt2.*(div_Vs2  - div_Vs2/3));
    dVx2           = diff(-Pt2+tau_xx2,1,1)/dx.*dt2./rho0;
    Vx2(2:end-1)   = (Vx2(2:end-1)     +     dVx2  )./(1+0*Gdt+1*damp./nx); 
    Ux2             = Ux2 + Vx2*dt;
    error2(iter)   = max(abs(Vx2(:)))/Lx; %(max(abs(dVx2(:)))/Lx)./max(abs(Vx2(:)));
    if mod(iter,nout)==0 
        subplot(3,1,1), plot(x,(Vx(2:end) + Vx(1:end-1))/2,'k-','linewidth',1.5),    
        hold on; plot(x,(Vx2(2:end) + Vx2(1:end-1))/2,'g--','linewidth',1.5),title('Velocity, v_x (-)'),  
        xlabel( 'x (-)'  ); ylabel( 'Amplitude (-)'  );hold off
        subplot(3,1,2), plot(x,-Pt+tau_xx,'k-','linewidth',1.5), title(['Stress, \sigma (-), damping scheme 2']); 
        xlabel( 'x (-)'  ); ylabel( 'Amplitude (-)'  );
        subplot(3,1,3), plot(x,-Pt2+tau_xx2,'g--','linewidth',1.5), title(['Stress, \sigma (-), damping scheme 1']);
        %xlabel(['it = ', num2str(it) ,'  iter = ', num2str(iter)]),
        xlabel( 'x (-)'  );ylabel( 'Amplitude (-)'  );
        drawnow;
    end
    if error(iter) < eiter,break,end 
    end
end
subplot(3,1,1), legend('Damping scheme 2','Damping scheme 1')
%error_print = error(iter)

% l = linspace(0,Vx2(1),nx+1);
% sum_x2 = sum(l(:));

Sxx = (-Pt(:)+tau_xx(:)); Av_Sxx = sum(Sxx(:));
Exx = diff(Ux,1,1)/dx; Av_Exx = sum(Exx(:));
er1 = (Av_Sxx)./(Av_Exx) - (K0+4/3*G0)
%er1 = sum(Vx(:))-sum_x2

Sxx2 = (-Pt2(:)+tau_xx2(:)); Av_Sxx2 = sum(Sxx2(:));
Exx2 = diff(Ux2,1,1)/dx; Av_Exx2 = sum(Exx2(:));
er2 = (Av_Sxx2)./(Av_Exx2) - (K0+4/3*G0)
%er2 = sum(Vx2(:))-sum_x2

zzzz = 1;





