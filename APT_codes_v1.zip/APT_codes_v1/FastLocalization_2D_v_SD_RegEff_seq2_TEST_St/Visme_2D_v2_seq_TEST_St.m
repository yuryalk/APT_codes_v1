%clear,
figure(3),clf,colormap jet
% Written by Yury Alkhimenkov with the support of Ivan Utkin, Lyudmila Khakimova, Yury Y. Podladchikov
% Massachusetts Institute of Technology
% This script is developed to run the CUDA C routine "FastLocalization_2D_v1.cu" and visualize the results

% This script:
% 1) creates parameter files
% 2) compiles and runs the code on a GPU
% 3) visualize the result
%%
% Physics
K        = 1;       %  bulk modulus, Pa
G0       = 1;       % shear modulus, Pa
coh0     =    1e-2*G0;
P0       =    coh0/2;
rad0     = 1/15+0* 1;       % Radius of the hole
fric     = 0.6;
Lx       = 1+0*10*rad0; % model length in x
Ly       = 1*Lx;    % model length in y
eta_reg  = 0.02*1e-3;
nt       = 15+0*40;
dt       = 4*1e-5; sc = 1;
% Boundary conditions
P_in     = 0.0*coh0;
P_inf    = 2.0*coh0;
tau_inf  =-0.2*coh0;
%loading
Strain0   = 4.8e-3*[1 -1  0];
Strain0   =  6e-3*[1 -1  0];
%% 1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111
% Numerical grid
% NBX is the input parameter to GPU
NBX = 8*1;NBY = 8*1;
BLOCK_X  = 32; % BLOCK_X*BLOCK_Y<=1024
BLOCK_Y  = 32;
GRID_X   = NBX*2;GRID_Y   = NBY*2;
OVERLENGTH_X = 1;OVERLENGTH_Y = OVERLENGTH_X;
nx = BLOCK_X*GRID_X  - OVERLENGTH_X; % size of the model in x
ny = BLOCK_Y*GRID_Y  - OVERLENGTH_Y; % size of the model in y
% preprocessing
dx       = Lx/(nx-1);
dy       = Ly/(ny-1);
[x,y]    = ndgrid(-Lx/2:dx:Lx/2  ...
    ,             -Ly/2:dy:Ly/2);
rad   = sqrt(x.^2+y.^2);
Pt        = zeros(nx  ,ny  ); %Pt(rad<rad0) =  P0;
Gm      = G0*ones(nx,ny); %Gm(rad<rad0) = G0/2;
lamx = 0.2; lamy=0.2;lamC=0.2;
Gm      = Gm-0*0.2*exp(-(x/lamx).^2-(y/lamy).^2);
coh0m  = 1.2*1e-2*G0  -  0.05*1e-2*G0*exp(-(x/lamC).^2-(y/lamC).^2);
bp = 25;
%coh0m([1:fix(nx/bp)  end-fix(nx/bp):end],:) = 2.0*1e-2*G0;
%coh0m(:,[1:fix(nx/bp)  end-fix(nx/bp):end])= 2.0*1e-2*G0;
imagesc(coh0m);axis image;cl=colorbar;title(cl,'c (-)'); 
xticks(['']);yticks(['']);drawnow
ii = 0; error = 0;
ii_max = 15; 
for ii = 1:ii_max
Txx       = zeros(nx  ,ny  )  +   G0*(Strain0(1) - Strain0(2));
Tyy       = zeros(nx  ,ny  )  +   G0*(Strain0(2) - Strain0(1));
Txy      = zeros(nx+1,ny+1)  + 2*G0*Strain0(3);
Pt       = zeros(nx  ,ny  )  +   0.0040+0*G0*(Strain0(1) - Strain0(2));
eb = 1;
[xVx,yVx] = ndgrid(-Lx/2-dx/2:dx:Lx/2+dx/2,-Ly/2:dy:Ly/2);
[xVy,yVy] = ndgrid(-Lx/2:dx:Lx/2,-Ly/2-dy/2:dy:Ly/2+dy/2);
Vx     =  eb*xVx;
Vy     = -eb*yVy;
Re     = linspace(0.5,2,ii_max).*(2.0 * sqrt(2.0) / 1.0 * pi);
pa1         = [nt eta_reg dt Re(ii)];
fid         = fopen('pa1.dat','wb'); fwrite(fid,pa1(:),'double'); fclose(fid);
fid      = fopen('Pt.dat','wb'); fwrite(fid, Pt(:),'double'); fclose(fid);
fid      = fopen('Gm.dat','wb'); fwrite(fid, Gm(:),'double'); fclose(fid);
fid      = fopen('coh0m.dat','wb'); fwrite(fid, coh0m(:),'double'); fclose(fid);
fid      = fopen('Txx.dat','wb'); fwrite(fid, Txx(:),'double'); fclose(fid);
fid      = fopen('Tyy.dat','wb'); fwrite(fid, Tyy(:),'double'); fclose(fid);
fid      = fopen('Txyc.dat','wb'); fwrite(fid, Txy(:),'double'); fclose(fid);
fid      = fopen('Vx.dat','wb'); fwrite(fid, Vx(:),'double'); fclose(fid);
fid      = fopen('Vy.dat','wb'); fwrite(fid, Vy(:),'double'); fclose(fid);
%%
%%
code_name    = 'FastLocalization_2D_v1';
    run_cmd      =['nvcc -arch=sm_80 -O3' ' -DNBX='  int2str(NBX) ' -DNBY='  int2str(NBY) ' ',code_name,'.cu'];
if ii==1; system(run_cmd); end
! a.exe  
%> output.txt &
%%
infos = load('infos.inf');  PRECIS=infos(1); nx=infos(2); ny=infos(3); NB_PARAMS=infos(4); NB_EVOL=infos(5);
if (PRECIS==8), DAT = 'double';  elseif (PRECIS==4), DAT = 'single';  end
% figure(5),clf,colormap(jet(500));
% mfile = mfilename('fullpath');mfile = mfile(max(find(mfile=='\'))+1:end);
% wdir = pwd;                    wdir =  wdir(max(find( wdir=='\'))+1:end);
% movie_name = [wdir,'_',mfile,'.gif'];
isave = nt;
 id = fopen( [int2str(isave),'_0_evol.res']);   evol   = fread(id,DAT); fclose(id);  evol   = reshape(evol  ,3000  ,15);
% fh = figure(5);clf;colormap(jet(500)); %Sxxt=0;evol=0;
% semilogy(evol(:,1),'-x');
% drawnow
 
error(ii) = evol(285,1);
end
fh = figure(5);clf;colormap(jet(500)); %Sxxt=0;evol=0;
semilogy(Re,error,'-x'); hold on;

Re_opt  = (2.0 * sqrt(2.0) / 1.0 * pi);
loglog( [Re_opt Re_opt],[1e-11 1e-6],'LineWidth',1);

Re_opt2 = (3.0 * sqrt(10.0) / 2.0 * pi);
loglog( [Re_opt2 Re_opt2],[1e-11 1e-6],'LineWidth',1);

xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ error$ (-)','Interpreter','latex'  );
legend('Numerical solution', ...
    '$   {\mathrm{St}}_\textrm{opt} = 2 \sqrt{2}\, \pi  $ ',...
    '$\mathrm{St} = 3 \sqrt{10}\, \pi /2$', 'Interpreter','latex');
grid on; drawnow

drawnow

%%
%delete a.exe *.dat *.res *.inf
%%
zzz = 1;
function A_av = av4(A)
A_av = 0.25*(A(1:end-1,1:end-1)...
    +        A(1:end-1,2:end  )...
    +        A(2:end  ,1:end-1)...
    +        A(2:end  ,2:end  ));
end