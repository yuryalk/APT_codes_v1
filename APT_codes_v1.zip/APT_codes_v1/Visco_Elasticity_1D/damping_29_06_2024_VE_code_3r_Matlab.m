clear, figure(1), clf
%physics
Lx    = 1;
w     = pi;
u0    = 1;
G0    = 1;
K0    = 1*G0;
eta   = 1.0;
%numerics
nx    = 401;
nt    = 70*nx;
K_G   = 1;
G     = 1;
K     = 1*G;
CFL   = 1/1.001;
%preprocessing
dx    = Lx/(nx-1);
x     = 0:dx:Lx;
for ipar = 1:25
    par      = 1+ipar/1;
    St      = par; 
    dt       = 1;
    Vpdt     = dx*CFL;
    H        =  (K0*1+4/3*1+0*G0).*dt;
    %H        =  (K0*1+4/3*1+0).*dt;
    eta_ve   = 1./(1./eta*1 + 1./(H));
    dt_rho   = Vpdt.*Lx./St./eta_ve;
    Gdt      = Vpdt^2./dt_rho/(K_G+4/3);
    Gr       = Gdt./(G.*dt);
    Kdt      = K_G.*Gdt; %Kdt - numer;
    Kr       = Kdt./(K.*dt);
    % initial
    V        = u0*sin(w*x/Lx);
    Pr       = 1*diff(V);
    tau      = Pr*1;
    for it = 1:nt
        Pr         = (Pr          - Kdt.*diff(V)/dx)./(1 + Kr)   ;  
        tau        = (tau + 2* Gdt.*( (diff(V)/dx - diff(V)/dx/3)  ))./(1 +  1*Gdt./eta+Gr); 
        V(2:end-1) = V(2:end-1)      + dt_rho*diff(-Pr + tau)/dx;
        if it == 1, mfun        = max(abs(V)) + max(abs(tau)) + max(abs(Pr));   end
        if (max(abs(V)) + max(abs(tau)) + max(abs(Pr))) < 1e-9*mfun,break;end
    end
    iters1(ipar) = it;    ipars1(ipar) = par;
    Maximum = iters1/nx; [find, find2] = min(Maximum(:)) ;  
end
Reopt_num = ipars1(find2);
omega = 1; iparmax = 25;
for ipar = 1:iparmax
    par   = 1+ipar/1 ;
    St   = par;
    rho   = St^2*H^2/((1*K+4/3*G)*Lx^2); 
    dt    = dx/sqrt((1*K+4/3*G)/rho);
    Vs    = sqrt((1*K+4/3*G)/rho); fun    = 1;
    for it = 1:nt  
        fun_old=fun;        
         
        a1 =(10*pi^2)/21; 
        a2= 10/9*pi*pi/St + 1/5*St ; 
        a3= 1 ; 
        a4= 10/9/St;

        A = [a1 a2 a3 a4];
        Pol2        = roots( flip(A));        lambda       = max(real(Pol2));
        fun         = exp(  lambda(1)*Vs*it*dt ./Lx     ) ; 
        if it == 1, mfun        = max(abs(   exp( lambda(1)*Vs*it*dt./Lx   )  ));   end 
        err         = fun - fun_old;        merr        = max(abs(fun)); 
        if merr*6 < 1.0 *1e-9*mfun,break,end 
    end
    iters(ipar)     = it;
end
figure(1);clf
plot(ipars1,iters1/nx,'-x','LineWidth',1 ) 
hold on; plot( 1+(1:iparmax)/1 ,iters/nx, 'o','MarkerSize',10,'LineWidth',1.5);  hold on;
Re_opt =  16.38387532;
plot( [Re_opt Re_opt],[5 15],'LineWidth',3);hold on
plot( [Reopt_num Reopt_num],[5 15],'LineWidth',3); hold on
xlabel( '$ {\mathrm{St}}$ (-)','Interpreter','latex'  ); 
ylabel( '$ {n}_\textrm{iter}/n_x$ (-)','Interpreter','latex'  );
legend('Numerical solution','Analytical solution',...
    '$   {\mathrm{St}}_\textrm{opt} = 16.38  $ ',...
    '${\mathrm{St}} - \textrm{numerical}$', 'Interpreter','latex');
grid on; drawnow




       